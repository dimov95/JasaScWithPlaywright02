import { user } from "./users.js";
import { items } from "./items.js";

export const requests = {
    user,
    items
};